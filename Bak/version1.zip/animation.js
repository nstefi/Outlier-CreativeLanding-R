const canvas = document.getElementById('waveCanvas');
const ctx = canvas.getContext('2d');

// Set canvas size
function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

resizeCanvas();
window.addEventListener('resize', resizeCanvas);

// Animation parameters
const curves = [];
const numCurves = 8;  // Fewer curves
const pointsPerCurve = 20;  // Fewer points per curve
let time = 0;

// Create curves
for (let i = 0; i < numCurves; i++) {
    const curve = [];
    const curveLength = 0.3 + Math.random() * 0.7; // Random length for each curve (30-100% of full circle)
    const curveRadius = 100 + Math.random() * 100; // Random radius
    const startAngle = Math.random() * Math.PI * 2; // Random starting position
    
    for (let j = 0; j < pointsPerCurve; j++) {
        const progress = j / (pointsPerCurve - 1);
        const angle = startAngle + progress * Math.PI * 2 * curveLength;
        
        curve.push({
            baseX: Math.cos(angle) * curveRadius,
            baseY: Math.sin(angle * 2) * 50,
            baseZ: Math.sin(angle) * curveRadius,
            phase: Math.random() * Math.PI * 2,
            amplitude: 30 + Math.random() * 40, // Random movement amplitude
            speed: 0.5 + Math.random() * 1.5    // Random movement speed
        });
    }
    curves.push(curve);
}

// 3D rotation matrices
function rotateX(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const y = point.y * cos - point.z * sin;
    const z = point.y * sin + point.z * cos;
    return { ...point, y, z };
}

function rotateY(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const x = point.x * cos - point.z * sin;
    const z = point.x * sin + point.z * cos;
    return { ...point, x, z };
}

function rotateZ(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const x = point.x * cos - point.y * sin;
    const y = point.x * sin + point.y * cos;
    return { ...point, x, y };
}

// Animation function
function animate() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Rotation angles
    const rotationX = time * 0.0007;
    const rotationY = time * 0.001;
    const rotationZ = time * 0.0005;

    curves.forEach((curve, curveIndex) => {
        curve.forEach((point, i) => {
            // Calculate more dynamic morphing effect
            const timeOffset = time * point.speed;
            const xMorph = Math.sin(timeOffset + point.phase) * point.amplitude;
            const yMorph = Math.cos(timeOffset * 0.7 + point.phase) * point.amplitude;
            const zMorph = Math.sin(timeOffset * 1.3 + point.phase) * point.amplitude;
            
            // Apply base position with morphing
            let x = point.baseX + xMorph;
            let y = point.baseY + yMorph;
            let z = point.baseZ + zMorph;

            // Apply rotations
            let rotated = rotateX({ x, y, z }, rotationX);
            rotated = rotateY(rotated, rotationY);
            rotated = rotateZ(rotated, rotationZ);

            // Project to 2D with perspective
            const perspective = 1000;
            const distance = perspective / (perspective - rotated.z);
            
            const projectedX = rotated.x * distance + centerX;
            const projectedY = rotated.y * distance + centerY;

            // Calculate dot size and opacity based on z position
            const baseSize = 3;
            const size = baseSize * distance;
            const opacity = Math.min(1, Math.max(0.2, (rotated.z + 200) / 400));

            // Draw glowing dot
            const gradient = ctx.createRadialGradient(
                projectedX, projectedY, 0,
                projectedX, projectedY, size * 3
            );
            gradient.addColorStop(0, `rgba(0, 150, 255, ${opacity})`);
            gradient.addColorStop(0.5, `rgba(0, 100, 255, ${opacity * 0.3})`);
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

            ctx.beginPath();
            ctx.fillStyle = gradient;
            ctx.arc(projectedX, projectedY, size * 3, 0, Math.PI * 2);
            ctx.fill();

            // Draw center dot
            ctx.beginPath();
            ctx.fillStyle = `rgba(200, 240, 255, ${opacity})`;
            ctx.arc(projectedX, projectedY, size, 0, Math.PI * 2);
            ctx.fill();
        });
    });

    time++;
    requestAnimationFrame(animate);
}

animate(); 