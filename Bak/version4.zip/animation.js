const canvas = document.getElementById('waveCanvas');
const ctx = canvas.getContext('2d');

// Set canvas size
function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

resizeCanvas();
window.addEventListener('resize', resizeCanvas);

// Animation parameters
const lines = [];
const numLines = 15;        // Number of parallel lines
const pointsPerLine = 25;   // Points per line
const lineSpacing = 30;     // Space between parallel lines
let time = 0;

// Create parallel lines of points
for (let i = 0; i < numLines; i++) {
    const line = [];
    const lineOffset = (i - numLines / 2) * lineSpacing;
    
    // Add unique properties for each line
    const lineProperties = {
        phaseOffset: Math.random() * Math.PI * 2,
        frequencyOffset: 0.8 + Math.random() * 0.4,
        amplitudeOffset: 0.8 + Math.random() * 0.4,
        rotationOffset: Math.random() * 0.4 - 0.2
    };
    
    for (let j = 0; j < pointsPerLine; j++) {
        const xPos = (j - pointsPerLine / 2) * lineSpacing;
        line.push({
            baseX: xPos,
            baseY: 0,
            baseZ: lineOffset,
            phase: (i / numLines) * Math.PI * 2,
            lineProps: lineProperties
        });
    }
    lines.push(line);
}

// 3D rotation matrices
function rotateX(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const y = point.y * cos - point.z * sin;
    const z = point.y * sin + point.z * cos;
    return { ...point, y, z };
}

function rotateY(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const x = point.x * cos - point.z * sin;
    const z = point.x * sin + point.z * cos;
    return { ...point, x, z };
}

function rotateZ(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const x = point.x * cos - point.y * sin;
    const y = point.x * sin + point.y * cos;
    return { ...point, x, y };
}

// Animation function
function animate() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Base rotation angles
    const rotationX = time * 0.0003;
    const rotationY = time * 0.0004;
    const rotationZ = time * 0.0002;

    // Store projected points for line drawing
    const projectedPoints = [];

    // First pass: calculate all projected points
    lines.forEach((line, lineIndex) => {
        const projectedLine = [];
        
        line.forEach((point, i) => {
            const props = point.lineProps;
            
            // Calculate distorted wave motion
            const timeScale = time * 0.02 * props.frequencyOffset;
            const xDistortion = Math.sin(timeScale * 0.7 + point.phase) * 15;
            const yDistortion = Math.sin(timeScale + point.phase + i * 0.2) * 40 * props.amplitudeOffset;
            const zDistortion = Math.cos(timeScale * 0.5 + point.phase) * 15;
            
            // Apply base position with distorted wave motion
            let x = point.baseX + xDistortion;
            let y = point.baseY + yDistortion;
            let z = point.baseZ + zDistortion;

            // Apply individual line rotation offsets
            let rotated = rotateX({ x, y, z }, rotationX + props.rotationOffset * Math.sin(time * 0.001));
            rotated = rotateY(rotated, rotationY + props.rotationOffset * Math.cos(time * 0.001));
            rotated = rotateZ(rotated, rotationZ);

            // Add subtle spiral effect
            const spiralAngle = (i / pointsPerLine) * Math.PI * 0.5 + time * 0.001;
            const spiralRadius = 5 * Math.sin(timeScale * 0.3);
            rotated.x += Math.cos(spiralAngle) * spiralRadius;
            rotated.z += Math.sin(spiralAngle) * spiralRadius;

            // Project to 2D with perspective
            const perspective = 1200;
            const distance = perspective / (perspective - rotated.z);
            
            const projectedX = rotated.x * distance + centerX;
            const projectedY = rotated.y * distance + centerY;
            const opacity = Math.min(1, Math.max(0.2, (rotated.z + 200) / 400));

            projectedLine.push({
                x: projectedX,
                y: projectedY,
                z: rotated.z,
                opacity
            });
        });
        
        projectedPoints.push(projectedLine);
    });

    // Second pass: draw the wireframe
    ctx.lineWidth = 1;

    // Draw horizontal lines
    projectedPoints.forEach((line, lineIndex) => {
        ctx.beginPath();
        line.forEach((point, i) => {
            if (i === 0) {
                ctx.moveTo(point.x, point.y);
            } else {
                ctx.lineTo(point.x, point.y);
            }
        });
        ctx.strokeStyle = `rgba(0, 150, 255, ${line[0].opacity * 0.5})`;
        ctx.stroke();
    });

    // Draw vertical lines
    for (let i = 0; i < pointsPerLine; i++) {
        ctx.beginPath();
        projectedPoints.forEach((line, lineIndex) => {
            const point = line[i];
            if (lineIndex === 0) {
                ctx.moveTo(point.x, point.y);
            } else {
                ctx.lineTo(point.x, point.y);
            }
        });
        const opacity = (projectedPoints[0][i].opacity + projectedPoints[projectedPoints.length-1][i].opacity) / 2;
        ctx.strokeStyle = `rgba(0, 150, 255, ${opacity * 0.5})`;
        ctx.stroke();
    }

    // Draw points at intersections for better definition
    projectedPoints.forEach(line => {
        line.forEach(point => {
            ctx.beginPath();
            ctx.fillStyle = `rgba(0, 150, 255, ${point.opacity})`;
            ctx.arc(point.x, point.y, 1, 0, Math.PI * 2);
            ctx.fill();
        });
    });

    time++;
    requestAnimationFrame(animate);
}

animate(); 