const canvas = document.getElementById('waveCanvas');
const ctx = canvas.getContext('2d');

// Set canvas size
function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

resizeCanvas();
window.addEventListener('resize', resizeCanvas);

// Animation parameters
const lines = [];
const numLines = 15;        // Number of parallel lines
const pointsPerLine = 25;   // Points per line
const lineSpacing = 30;     // Space between parallel lines
let time = 0;

// Create parallel lines of points
for (let i = 0; i < numLines; i++) {
    const line = [];
    const lineOffset = (i - numLines / 2) * lineSpacing;
    
    for (let j = 0; j < pointsPerLine; j++) {
        const xPos = (j - pointsPerLine / 2) * lineSpacing;
        line.push({
            baseX: xPos,
            baseY: 0,
            baseZ: lineOffset,
            phase: (i / numLines) * Math.PI * 2 // Phase offset based on line position
        });
    }
    lines.push(line);
}

// 3D rotation matrices
function rotateX(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const y = point.y * cos - point.z * sin;
    const z = point.y * sin + point.z * cos;
    return { ...point, y, z };
}

function rotateY(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const x = point.x * cos - point.z * sin;
    const z = point.x * sin + point.z * cos;
    return { ...point, x, z };
}

function rotateZ(point, angle) {
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    const x = point.x * cos - point.y * sin;
    const y = point.x * sin + point.y * cos;
    return { ...point, x, y };
}

// Animation function
function animate() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Slower rotation angles
    const rotationX = time * 0.0003;
    const rotationY = time * 0.0004;
    const rotationZ = time * 0.0002;

    lines.forEach((line, lineIndex) => {
        line.forEach((point, i) => {
            // Slower wave motion
            const waveX = 0;  // No horizontal wave
            const waveY = Math.sin(time * 0.02 + point.phase + i * 0.2) * 40;
            const waveZ = 0;  // No depth wave
            
            // Apply base position with wave motion
            let x = point.baseX + waveX;
            let y = point.baseY + waveY;
            let z = point.baseZ + waveZ;

            // Apply rotations
            let rotated = rotateX({ x, y, z }, rotationX);
            rotated = rotateY(rotated, rotationY);
            rotated = rotateZ(rotated, rotationZ);

            // Project to 2D with perspective
            const perspective = 1200;  // Increased perspective distance
            const distance = perspective / (perspective - rotated.z);
            
            const projectedX = rotated.x * distance + centerX;
            const projectedY = rotated.y * distance + centerY;

            // Calculate dot size and opacity based on z position
            const baseSize = 2;  // Smaller base size
            const size = baseSize * distance;
            const opacity = Math.min(1, Math.max(0.2, (rotated.z + 200) / 400));

            // Draw glowing dot
            const gradient = ctx.createRadialGradient(
                projectedX, projectedY, 0,
                projectedX, projectedY, size * 2
            );
            gradient.addColorStop(0, `rgba(0, 150, 255, ${opacity})`);
            gradient.addColorStop(0.5, `rgba(0, 100, 255, ${opacity * 0.3})`);
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

            ctx.beginPath();
            ctx.fillStyle = gradient;
            ctx.arc(projectedX, projectedY, size * 2, 0, Math.PI * 2);
            ctx.fill();

            // Draw center dot
            ctx.beginPath();
            ctx.fillStyle = `rgba(200, 240, 255, ${opacity})`;
            ctx.arc(projectedX, projectedY, size, 0, Math.PI * 2);
            ctx.fill();
        });
    });

    time++;
    requestAnimationFrame(animate);
}

animate(); 