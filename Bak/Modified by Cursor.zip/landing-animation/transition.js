document.addEventListener('DOMContentLoaded', () => {
    const splashScreen = document.querySelector('.splash-screen');
    const mainContent = document.querySelector('.main-content');
    const titleLines = document.querySelectorAll('.title-line');
    const exploreBtn = document.querySelector('.explore-btn');
    const canvas = document.getElementById('waveCanvas');

    // Initial setup
    mainContent.style.visibility = 'hidden';
    mainContent.style.opacity = '0';

    // Animate title lines with staggered delay
    titleLines.forEach((line, index) => {
        setTimeout(() => {
            line.classList.add('visible');
        }, 500 + (index * 200)); // Stagger each line by 200ms
    });

    // Show explore button after title animation
    setTimeout(() => {
        exploreBtn.classList.add('visible');
    }, 500 + (titleLines.length * 200));

    // Handle transition when explore button is clicked
    exploreBtn.addEventListener('click', () => {
        // Start fade out animation for splash screen
        splashScreen.style.opacity = '0';
        
        // Gradually reduce canvas opacity
        let canvasOpacity = 1;
        const fadeCanvas = setInterval(() => {
            canvasOpacity -= 0.02;
            canvas.style.opacity = canvasOpacity;
            
            if (canvasOpacity <= 0) {
                clearInterval(fadeCanvas);
            }
        }, 16);

        // After splash screen fades out
        setTimeout(() => {
            splashScreen.style.display = 'none';
            mainContent.style.visibility = 'visible';
            
            // Fade in main content
            requestAnimationFrame(() => {
                mainContent.style.opacity = '1';
            });

            // Optional: Stop the canvas animation to save resources
            // You can add this if you want to completely stop the animation
            // canvas.style.display = 'none';
        }, 1000); // Match this with the CSS transition duration
    });
}); 